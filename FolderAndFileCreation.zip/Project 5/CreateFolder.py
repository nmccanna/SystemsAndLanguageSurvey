# Nikhil McCanna
# Windows 11 23H2

import os
import shutil
import random

def create_folder_and_save_numbers():
    # Ask user for name of folder
    folder_name = input("Enter the name of the folder to be created: ")

    # Check if folder exists
    if os.path.exists(folder_name):
        # Remove existing folder
        shutil.rmtree(folder_name)
        print(f"Existing folder '{folder_name}' has been removed.")

    # Create new folder
    os.makedirs(folder_name)
    print(f"New folder '{folder_name}' has been created.")

    # Generate 100 random numbers from 0 to 1000
    random_numbers = [random.randint(0, 1000) for _ in range(100)]

    # Save numbers in file named "numbers100.txt" inside created folder
    file_path = os.path.join(folder_name, "numbers100.txt")
    with open(file_path, 'w') as file:
        for number in random_numbers:
            file.write(f"{number}\n")

    print(f"100 random numbers have been saved in '{file_path}'.")

if __name__ == "__main__":
    create_folder_and_save_numbers()
